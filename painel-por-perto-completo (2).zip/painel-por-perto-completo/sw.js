/*
  Por Perto - trabalhador de servico (service worker)

  Ele existe por UM motivo so: o Android so oferece "Instalar aplicativo"
  para paginas que tenham um arquivo destes.

  DE PROPOSITO ele NAO guarda nada em cache.
  Se guardasse, o filho continuaria vendo a versao antiga do painel
  depois que voce subisse uma nova no Netlify. Aqui ele so deixa o
  pedido passar direto para a internet, como se nao existisse.
*/

self.addEventListener("install", () => self.skipWaiting());

self.addEventListener("activate", e => e.waitUntil(self.clients.claim()));

self.addEventListener("fetch", e => {
  e.respondWith(fetch(e.request));
});
